<?php
// datastore=auditqueue;
// created_on=1574104655;
// updated_on=1574104655;
exit(0);
?>
1574104655_4901:"Warning: 127.0.0.1; Plugin activated: Sucuri Security - Auditing, Malware Scanner and Hardening (v1.8.21; sucuri-scanner\/sucuri.php)"
1574104758_0334:"Notice: arvind, 118.173.39.219; Post status has been changed; details: ID: 4,Old status: new,New status: auto-draft,Title: Auto Draft"
1574104809_1868:"Warning: arvind, 118.173.39.219; Plugin activated: All-in-One WP Migration (v7.10; all-in-one-wp-migration\/all-in-one-wp-migration.php)"
1574104894_641:"Warning: arvind, 118.173.39.219; Plugin activated: WP Htaccess Editor (v1.65; wp-htaccess-editor\/wp-htaccess-editor.php)"
1574105829_8979:"Warning: arvind, 118.173.39.219; Plugin activated: Custom PHP settings (v1.2.6; custom-php-settings\/bootstrap.php)"
1574106748_6725:"Warning: arvind, 118.173.39.219; Plugin installed: all-in-one-wp-migration-unlimited-extension-v-2-32-nulled.zip"
1574106748_7808:"Notice: arvind, 118.173.39.219; Media file added; ID: 5; name: all-in-one-wp-migration-unlimited-extension-v-2-32-nulled.zip; type: "
1574106749_555:"Warning: arvind, 118.173.39.219; Post deleted: (multiple entries): Post id: 5"
1574106752_8928:"Warning: arvind, 118.173.39.219; Plugin activated: All-in-One WP Migration Unlimited Extension (v2.31; all-in-one-wp-migration-unlimited-extension\/all-in-one-wp-migration-unlimited-extension.php)"
1574143398_9489:"Warning: arv, 118.173.39.219; Plugin activated: Sucuri Security - Auditing, Malware Scanner and Hardening (v1.8.21; sucuri-scanner\/sucuri.php)"
1574143412_4881:"Warning: arv, 118.173.39.219; Plugin activated: Custom PHP settings (v1.2.6; custom-php-settings\/bootstrap.php)"
1574143425_2754:"Warning: arv, 118.173.39.219; Plugin activated: GDPR Cookie Consent (v1.8.1; cookie-law-info\/cookie-law-info.php)"
1574143435_8486:"Warning: arv, 118.173.39.219; Plugin activated: Google Analytics for WordPress by MonsterInsights (v7.10.0; google-analytics-for-wordpress\/googleanalytics.php)"
1574145778_7239:"Warning: arv, 118.173.39.219; Plugin deactivated: Really Simple SSL (v3.2.6; really-simple-ssl\/rlrsssl-really-simple-ssl.php)"
