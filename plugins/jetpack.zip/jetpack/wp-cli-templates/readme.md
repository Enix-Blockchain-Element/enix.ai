# Templates

These templates are used by the `wp jetpack block` WP-CLI command. They're used to generate files that are written to build an skeleton for a Jetpack block.
