<?php
/**
 * Silence is golden.
 */
